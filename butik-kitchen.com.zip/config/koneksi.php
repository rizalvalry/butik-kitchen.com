<?php

$host = "localhost";
$dbs = "butikkitchen";
$user = "root";
$pass = "";

$db = new mysqli($host, $user, $pass, $dbs);
// if(!$db) {
//   die( print_r( $db));
// } else {
//     echo "berhasilkah";
// }