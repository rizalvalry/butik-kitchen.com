<?php
include "parser-php-version.php"; //Konversi dan migrasi PHP version

$servername = "localhost";
$database = "u4920924_tagihan";
$username = "u4920924_rizal";
$password = "12345";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Pesan Gagal Dikirim - Database tidak terhubung!: " . mysqli_connect_error());
}

 
$sql = "INSERT INTO payment (domain, email, layanan, dari, sampai, periode, harga, diskon, total) VALUES ('domain', 'email', 'layanan', 'dari', 'sampai', 'periode', 'harga', 'diskon', 'total')";
if (mysqli_query($conn, $sql)) {
      echo "Pesan Berhasil Dikirim";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
